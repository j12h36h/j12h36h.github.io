My First DAI Project v1.0.0

Purpose: Level 0 learning sample for DAI Engine 3.3.

1. Keep pack.mcmeta at the ZIP root.
2. Install/enable the datapack in a disposable test world.
3. Run /reload.
4. Open the DAI System menu.
5. Press SAY HELLO.

This sample intentionally overrides decisions_and_impulses:menus/systems/default for the learning exercise.
